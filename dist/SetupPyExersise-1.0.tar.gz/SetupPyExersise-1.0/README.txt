This is my setup.py exersize project.
