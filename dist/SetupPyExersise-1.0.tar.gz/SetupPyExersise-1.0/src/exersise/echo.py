def echo(phrase):
    return phrase

if __name__ == '__main__':
    print echo("hello")
